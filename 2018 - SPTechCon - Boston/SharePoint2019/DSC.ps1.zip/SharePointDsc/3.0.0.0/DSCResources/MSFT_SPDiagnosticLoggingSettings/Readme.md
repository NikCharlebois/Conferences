# Description

**Type:** Distributed

This resource is responsible for configuring settings to do with the diagnostic
(ULS) logging on servers in the farm. These settings are applied to the
diagnostic logging service for the farm and do not need to be applied to each
server individually, the settings will be propagated throughout the farm when
