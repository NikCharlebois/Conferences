# Description

**Type:** Distributed
**Requires CredSSP:** No

This resource is used to set the global antivirus settings for the local farm.
These settings will be used to control the behavior of an external anti-virus
scanning tool that is able to integrate with SharePoint. Note that this will
not scan documents for viruses on it's own, an external tool still needs to be
installed on the servers that integrates with SharePoint.
